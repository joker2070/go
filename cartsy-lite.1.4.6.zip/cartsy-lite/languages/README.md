# Please do not place your custom translation files here.

Cartsy Lite theme will look in this directory for translations as a fallback. It is recommended that you use the global WordPress language directory and install translations. That way they will not be lost or overwritten during Cartsy Lite updates. Alternatively you can put translations in your child theme.