<?php 
    if (!defined('ABSPATH')) {
        exit('Direct script access denied.');
    }
?>
<div class="cartsylite-menu-area"> <?php // phpcs:ignore Internal.NoCodeFound ?>