<?php 
    if (!defined('ABSPATH')) {
        exit('Direct script access denied.');
    }
?>
</div> <?php // phpcs:ignore Internal.NoCodeFound ?>